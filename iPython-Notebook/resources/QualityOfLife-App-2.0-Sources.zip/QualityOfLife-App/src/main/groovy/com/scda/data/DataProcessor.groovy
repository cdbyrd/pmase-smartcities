package com.scda.data

interface DataProcessor {

    void process()
    void output()

}

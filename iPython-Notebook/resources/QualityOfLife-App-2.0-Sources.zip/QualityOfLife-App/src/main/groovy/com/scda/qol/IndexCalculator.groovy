package com.scda.qol

interface IndexCalculator {

    void setup()
    void calculateIndex()
}
